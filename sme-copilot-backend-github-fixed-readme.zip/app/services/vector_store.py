# Stub for vector search / RAG. Replace with your implementation (e.g., PgVector, Pinecone, Weaviate).
def search(query: str, top_k: int = 5):
    return []
