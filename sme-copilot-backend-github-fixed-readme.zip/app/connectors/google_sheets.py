# Placeholder; implement OAuth and Sheets API calls here.
def fetch_sheet(spreadsheet_id: str, range_: str):
    return {"headers": ["date","revenue"], "rows":[["2024-01-01", 1000], ["2024-01-02", 1200]]}
